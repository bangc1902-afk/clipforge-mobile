# ClipForge Mobile + Claude starter kit

This kit contains a browser-side FFmpeg editor and a Claude Skill for preparing timestamped clip plans.

## Included
- `site/index.html`: mobile browser editor
- `claude/SKILL.md`: Claude instructions
- `examples/clip-plan.json`: sample plan

## Functions
- Cut multiple clips using start/end timestamps
- Split into equal-duration segments
- Compress to a smaller MP4
- Extract audio to MP3
- Download outputs individually or as ZIP

## Android setup
1. Extract this ZIP.
2. Publish the contents of `site/` as a static HTTPS site. For GitHub Pages: create a repository, upload `site/index.html` to its root, then Settings → Pages → deploy from `main` / root.
3. Open the HTTPS page in Chrome and optionally use menu → Add to Home screen.
4. Tap Load FFmpeg engine (first load downloads about 30 MB), select a local video, then use the controls.
5. Add `claude/SKILL.md` to Claude as a Skill. Ask Claude for a JSON clip plan and paste it into the editor.

## Important
- This is a local browser processing route, NOT a direct Claude-to-editor MCP connector. Claude creates the edit plan; you paste it into the browser app.
- It cannot fetch YouTube watch links. Use a source file you own or are permitted to edit.
- Large files may exceed mobile browser memory. Keep the page open and phone awake.
- The editor currently does not auto-detect highlights, add captions/music, or reframe vertical.
- The app loads FFmpeg WebAssembly and JS libraries from jsDelivr, so an internet connection is needed to start it.

## Documentation
FFmpeg.wasm: https://ffmpegwasm.netlify.app/docs/getting-started/usage/
Claude remote MCP: https://support.claude.com/en/articles/11175166-get-started-with-custom-connectors-using-remote-mcp
